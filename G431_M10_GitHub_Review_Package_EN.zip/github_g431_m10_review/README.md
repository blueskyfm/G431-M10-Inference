# G431-MM0 + Tesla M10: PCI BAR5 firmware experiment

**Status: experimental. Four physical M10 cards have booted and enumerated (16 GPU devices). Five to ten cards have not yet been retested with this change. This is not an official Gigabyte BIOS release.**

## Acknowledgements and inspiration

This investigation was inspired by the excellent [`m10dis` project](https://github.com/crgregersen/m10dis), especially its public documentation of Tesla M10 hardware, BAR5, and multi-GPU inference. Many thanks to **crgregersen** for sharing that work and making this investigation possible. This G431-MM0 BIOS experiment is independent and is not part of, maintained by, or endorsed by `m10dis`.

## Goal

The goal is an inexpensive inference host for several independent specialist agents, targeting **quantized models around 6B parameters**. The intention is not to run one giant model by treating all M10 memory as a single pool. Each physical Tesla M10 contains four GM107 GPUs with 8 GB each; the four devices are enumerated separately. Model fit and performance at 6B have not yet been benchmarked on this server.

The M10 cards were found on [this eBay France listing](https://www.ebay.fr/itm/880037037060?chn=ps&norover=1&mkevt=1&mkrid=709-134431-41854-0&mkcid=2&mkscid=101&itemid=880037037060&targetid=2501626380638&device=m&mktype=pla&googleloc=9219961&poi=&campaignid=24236806942&mkgroupid=200469000416&rlsatarget=pla-2501626380638&abcId=10823391&merchantid=6995724&gad_source=1&gad_campaignid=24236806942&gbraid=0AAAAACadmUl68qTjSAJJBUjnD2wQGHmCx&gclid=EAIaIQobChMIgqXd_ZyCmAMVjrVoCR0UXhl0EAQYAiABEgL0-_D_BwE) for about **€85 per card** when checked. The listing and price can change; this is not an endorsement or guarantee of the seller.

## Hardware and software

- Server: **GIGABYTE G431-MM0-OT**
- Motherboard/baseboard: **MJ11-EC1-OT**
- Original BIOS: F09, build date 2021-09-14
- Experimental BIOS label reported by Ubuntu: F10 (same build date)
- BMC: 12.61.39
- OS: Ubuntu 26.04.1 LTS
- Kernel: 7.0.0-43-generic
- NVIDIA driver: 580.178.04
- GPU: NVIDIA Tesla M10, PCI ID `10de:13bd`; four GM107 GPU devices per physical card

## Photo of the build

![GIGABYTE G431-MM0 chassis populated with ten NVIDIA Tesla M10 cards](assets/G431_MM0_Tesla_M10_build.jpeg)

The photo shows the ten-card physical build. It documents the hardware arrangement only: the post-change successful boot test currently covers four physical cards, not all ten.

## Problem observed

With the original setup, two and then three physical M10 cards worked. A five-card attempt stopped during POST with a “Please wait for chips” message and KVM POST code 70. The cards had been checked individually; no defective card was identified. The failure happened before Ubuntu/Linux could start, so a Linux-only change could not by itself address that POST failure.

## Firmware change under investigation

An experimental exception was added to the AMI `PciBus` driver's PCI resource exception table. It targets NVIDIA device `10de:13bd` and BAR5 (PCI configuration offset `0x24`) to suppress allocation of the M10's small I/O BAR. The aim is to reduce legacy I/O-port window pressure while leaving BAR0/BAR1/BAR3 and other devices' resources alone. No GPU VBIOS or NVIDIA driver was modified.

This is a narrow hypothesis based on the observed resource-allocation failure. It is **not** a general PCI resource fix and is not proven safe for other boards or devices.

## Results so far

| Configuration / check | Result |
|---|---|
| Original BIOS, 2–3 physical M10 cards | Boots and works for basic GPU detection |
| Original BIOS, 5 physical M10 cards | POST hang: “Please wait for chips”, KVM code 70 |
| Experimental BIOS, 4 physical M10 cards | Boots; `nvidia-smi -L | wc -l` returns `16` |
| Experimental BIOS, 5–10 physical M10 cards | **Not yet tested** |
| CUDA model inference, sustained load, thermal/power validation | **Not yet tested** |

The 16 entries are four GPU devices per physical M10 card. This proves detection/boot at four cards; it does not prove that ten cards will boot or that models run reliably.

## Verification performed

- The 16 MiB BIOS dump obtained from the BMC was compared byte-for-byte with the experimental payload. The bytes from offset `0x290000` onward match exactly; the PCI firmware volume containing `PciBus` starts at `0x294000`. The dump differed in 3,436 bytes before that offset, likely platform variable/configuration data; those differences have not been individually decoded.
- `dmidecode` now reports BIOS version `F10`; the BMC firmware-information page still reports `F09`. The custom image changed the SMBIOS version marker, while the BMC may display a different firmware identifier. The BMC display alone is not being used as proof of the PCI patch.
- Firmware-volume and FFS structural/checksum checks passed on the built image.
- Synthetic Unicorn emulation exercised the exception handler: the M10 BAR5 case is suppressed, while BAR0/BAR1/BAR3 and sampled existing exceptions remain unchanged. These are unit-level synthetic tests, not a full UEFI/PCIe/POST emulation.
- A real four-card POST and Ubuntu enumeration succeeded. No five-card post-change test has been completed.

## Reproducing or reviewing the patch

The public bundle includes the patch-builder script and synthetic verification results, **not** a ready-to-flash firmware image. Obtain the official BIOS for the exact board from [GIGABYTE support](https://www.gigabyte.com/Enterprise/GPU-Server/G431-MM0-rev-100/support), extract the matching `PciBus` PE image with UEFITool, and review `patch/build_module.py`. The script checks the exact source module hash and is expected to stop on a different source. It only builds the modified PE module; it does not create or certify a flashable RBU capsule.

The exact experimental RBU used on the author's server was built from a dump of that specific system. It is intentionally **not included here**: a full BIOS image may contain machine-specific configuration or identifiers, and the firmware contains Gigabyte code whose redistribution terms have not been established. Do not use someone else's dump or flash image on another system.

## Safety and limitations

- This is an unofficial, experimental modification. It can leave a system unbootable.
- It is currently validated only on one G431-MM0-OT / MJ11-EC1-OT system and only through four physical M10 cards.
- The post-change test at five cards, up to ten cards, inference, CUDA workloads, long-duration stability, cooling, PSU loading, and recovery procedure are not validated.
- The `m10dis` project documents a different system and additional Linux/hotplug techniques. Those should not be assumed to apply to this GIGABYTE server; any kernel-side BAR handling and its contribution here remain a separate question.
- Do not flash this firmware on a different board. Keep a known-good recovery path and original firmware backup.

## Questions for the community

1. Is suppressing BAR5 for only PCI ID `10de:13bd` in this AMI `PciBus` table a sound approach for avoiding I/O-window exhaustion on this board?
2. Are there known UEFI/AMI or AMD platform checks that could make this exception incomplete or unsafe?
3. What should be logged during stepwise 4-, 5-, …-card POST tests to distinguish PCI I/O allocation failure from power, bridge, or firmware initialization issues?
4. Could Linux re-probe or reassign BAR5 after boot, and what is the safest way to verify the final resource assignment?

Feedback and review are welcome. Please distinguish firmware-level POST results from Linux enumeration and actual inference benchmarks.
