# Patch builder notes

`build_module.py` expects `PciBus_original.pe` beside the script. That proprietary PE is deliberately not included. Extract it yourself from the exact official GIGABYTE BIOS for the exact board using UEFITool. The script checks the SHA-256 and expected PE layout; it will abort if the source differs. It outputs `PciBus_M10_BAR5_EXPERIMENTAL.pe`, not a complete BIOS or a flashable capsule.

The builder preserves the 16 original exception records and adds a specific record for vendor `0x10de`, device `0x13bd`, BAR register `0x24`. This is a review artifact, not a recommendation to flash.
