from pathlib import Path
import glob, hashlib, struct

out = Path(__file__).parent
source = out/'PciBus_original.pe'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == 'f252384354d29c590f6e846b2b36326970057f440575e0ae49e639dbcf852fc0'
b = bytearray(original)
pe = struct.unpack_from('<I', b, 0x3c)[0]
opt = pe + 24
n = struct.unpack_from('<H', b, pe+6)[0]
optsz = struct.unpack_from('<H', b, pe+20)[0]
last = opt + optsz + (n-1)*40
assert b[last:last+8] == b'.reloc\0\0'
vs, va, rs, rp = struct.unpack_from('<IIII', b, last+8)
assert (va, rs, rp, len(b)) == (0x14780, 0x60, 0x14780, 0x147e0)
assert b[0x73ca:0x73d6] == bytes.fromhex('488d1d3fb60000bf10000000')
# Preserve all 16 original records; add exact VID/DID and BAR register match.
table = bytes(b[0x12a10:0x12a10+16*40])
record = struct.pack('<IHHHHIQQQ', 3, 0x10de, 0x13bd, 0xffff, 0, 11, 0x24, 0, 0)
table_rva = va + rs
b.extend(table + record)
newvs = rs + len(table) + len(record)
newrs = (newvs+31) & ~31
b.extend(bytes(newrs-newvs))
struct.pack_into('<I', b, last+8, newvs)
struct.pack_into('<I', b, last+16, newrs)
# The appended table must survive PE relocation processing.
flags = struct.unpack_from('<I',b,last+36)[0]
struct.pack_into('<I', b, last+36, flags & ~0x02000000)
struct.pack_into('<I', b, opt+8, struct.unpack_from('<I',b,opt+8)[0]+newrs-rs)
struct.pack_into('<I', b, opt+56, va+newrs)
struct.pack_into('<i', b, 0x73cd, table_rva-0x73d1)
struct.pack_into('<I', b, 0x73d2, 17)
assert b[table_rva:table_rva+640] == table
assert b[0x12a10:0x12a10+640] == table
# No new absolute pointer; the original base relocation directory is unchanged.
assert b[opt+112+5*8:opt+112+6*8] == original[opt+112+5*8:opt+112+6*8]
target = out/'PciBus_M10_BAR5_EXPERIMENTAL.pe'
target.write_bytes(b)
print(target, len(b), hashlib.sha256(b).hexdigest())
