"""Emulate I/O BAR sizing caller and exception; PCI writes/list insert are mocked.
Not a complete PCI scan, UEFI boot, or hardware validation.
"""
from pathlib import Path
import struct,json
from unicorn import Uc, UC_ARCH_X86, UC_MODE_64, UC_HOOK_CODE
from unicorn.x86_const import *
root=Path(__file__).parent
B,D,S=0x1000000,0x2000000,0x3000000

def run(name,did,mask,old):
 image=(root/name).read_bytes();u=Uc(UC_ARCH_X86,UC_MODE_64)
 for b in [B,D,S]:u.mem_map(b,0x20000)
 u.mem_write(B,image)
 def q(a,v):u.mem_write(a,struct.pack('<Q',v))
 def readq(a):return struct.unpack('<Q',u.mem_read(a,8))[0]
 def ret():
  sp=u.reg_read(UC_X86_REG_RSP);u.reg_write(UC_X86_REG_RIP,readq(sp));u.reg_write(UC_X86_REG_RSP,sp+8);u.reg_write(UC_X86_REG_RAX,0)
 writes=[];insertions=[]
 def hook(uc,address,size,user):
  if address==B+0x104d4:ret()
  elif address==B+0xf55c:
   assert u.reg_read(UC_X86_REG_R8)&255==1
   writes.append(struct.unpack('<I',u.mem_read(u.reg_read(UC_X86_REG_R9),4))[0]);ret()
  elif address==B+0xf3e0:insertions.append(u.reg_read(UC_X86_REG_RCX));ret()
 u.hook_add(UC_HOOK_CODE,hook)
 q(B+0x134a8,0);q(B+0x134b0,D)
 u.reg_write(UC_X86_REG_RSP,S+0x10000);u.reg_write(UC_X86_REG_RSI,0)
 u.emu_start(B+0x73ca,B+0x740a,count=10000)
 dev=D+0x1000;res=dev+0xf8+5*0x40;sp=S+0x10000
 u.mem_write(dev+0xe8,struct.pack('<HH',0x10de,did));u.mem_write(dev+0x2e8,b'\x01')
 u.mem_write(res,struct.pack('<II',8,0));u.mem_write(res+0x20,b'\x24');q(res+0x38,dev)
 q(sp+0xb8,old)
 for reg,val in [(UC_X86_REG_RSP,sp),(UC_X86_REG_RDI,dev),(UC_X86_REG_RBP,res-0xf8),(UC_X86_REG_RSI,res),(UC_X86_REG_RBX,0x24),(UC_X86_REG_RAX,mask)]:u.reg_write(reg,val)
 u.emu_start(B+0x3ded,B+0x3f72,count=10000)
 assert u.reg_read(UC_X86_REG_RIP)==B+0x3f72
 typ=struct.unpack('<I',u.mem_read(res,4))[0]
 return dict(type=typ,size=readq(res+0x10),inserted=len(insertions),pci_writes=writes)
results=[]
for did in [0x13bd,0x13be]:
 for mask in [0x0000ff81,0xffffff81]:
  for old in [1,0xa001]:
   before=run('PciBus_original.pe',did,mask,old);after=run('PciBus_M10_BAR5_EXPERIMENTAL.pe',did,mask,old)
   if did==0x13bd:assert before['inserted']==1 and after['inserted']==0 and after['type']==0 and after['pci_writes'][-1]==0,(before,after)
   else:assert before==after
   results.append(dict(device=hex(did),mask=hex(mask),old=hex(old),before=before,after=after,result='PASS'))
(root/'caller_results.json').write_text(json.dumps(results,indent=2))
print(len(results),'caller scenarios PASS. Original caller reassigns size=1 after deletion, but type=0 skips insertion and BAR write becomes zero.')
