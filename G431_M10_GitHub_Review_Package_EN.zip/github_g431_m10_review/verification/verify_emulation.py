from pathlib import Path
import glob, struct, json
from unicorn import Uc, UC_ARCH_X86, UC_MODE_64, UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_RSP, UC_X86_REG_RIP, UC_X86_REG_RAX, UC_X86_REG_RSI, UC_X86_REG_RCX

root=Path(__file__).parent
original=(root/'PciBus_original.pe').read_bytes()
patched=(root/'PciBus_M10_BAR5_EXPERIMENTAL.pe').read_bytes()
B,D,S=0x1000000,0x2000000,0x3000000

def run(image,vid,did,bar,typ,size):
    u=Uc(UC_ARCH_X86,UC_MODE_64)
    for base in [B,D,S]: u.mem_map(base,0x20000)
    u.mem_write(B,image)
    def q(a,v): u.mem_write(a,struct.pack('<Q',v))
    # Execute actual table-registration loop. Only allocation helper is stubbed;
    # sufficient storage is preallocated for the table of pointers.
    q(B+0x134a8,0);q(B+0x134b0,D)
    u.reg_write(UC_X86_REG_RSP,S+0x10000)
    u.reg_write(UC_X86_REG_RSI,0)
    def hook(uc,address,size,user):
        if address==B+0x104d4:
            sp=uc.reg_read(UC_X86_REG_RSP)
            ret=struct.unpack('<Q',uc.mem_read(sp,8))[0]
            uc.reg_write(UC_X86_REG_RAX,0)
            uc.reg_write(UC_X86_REG_RSP,sp+8)
            uc.reg_write(UC_X86_REG_RIP,ret)
    h=u.hook_add(UC_HOOK_CODE,hook)
    u.emu_start(B+0x73ca,B+0x740a,count=10000)
    u.hook_del(h)
    count=struct.unpack('<Q',u.mem_read(B+0x134a8,8))[0]
    assert count==(17 if image==patched else 16)
    dev,res=D+0x1000,D+0x2000
    u.mem_write(dev+0xe8,struct.pack('<HH',vid,did))
    u.mem_write(res,struct.pack('<I',typ));q(res+0x10,size);q(res+0x18,size-1)
    u.mem_write(res+0x20,bytes([bar]));q(res+0x38,dev)
    sp=S+0x10008;q(sp,B+0x13000)
    u.reg_write(UC_X86_REG_RSP,sp);u.reg_write(UC_X86_REG_RCX,res)
    u.emu_start(B+0x2d90,B+0x13000,count=10000)
    return [struct.unpack('<I',u.mem_read(res,4))[0],struct.unpack('<Q',u.mem_read(res+0x10,8))[0]]

cases=[('M10 BAR5',0x10de,0x13bd,0x24,2,128),('M10 BAR0',0x10de,0x13bd,0x10,4,0x1000000),('M10 BAR1',0x10de,0x13bd,0x14,7,0x10000000),('M10 BAR3',0x10de,0x13bd,0x1c,7,0x2000000),('ASPEED',0x1a03,0x2000,0x18,2,128),('I210',0x8086,0x1533,0x18,2,32),('other NVIDIA',0x10de,0x13be,0x24,2,128)]
# Exercise each of the original 16 table records against both binaries.
for i in range(16):
    action,vid,did,mask,pad,kind,bar,unused,length=struct.unpack_from('<IHHHHIQQQ',original,0x12a10+40*i)
    cases.append((f'original exception {i}',vid,did,int(bar or 0x10),2 if kind==8 else 7,128 if kind==8 else 0x100000))
results=[]
for name,*args in cases:
    a,c=run(original,*args),run(patched,*args)
    if name=='M10 BAR5': assert a==[2,128] and c==[0,0],(a,c)
    else: assert a==c,(name,a,c)
    results.append(dict(case=name,before=a,after=c,result='PASS'))
(root/'emulation_results.json').write_text(json.dumps(results,indent=2))
print(f'{len(results)} cases passed; actual table registration and resource-exception routine emulated. No full boot or CUDA test.')
